#!/usr/bin/perl
use strict;
use warnings;

my %data = ();

while(<>){
    my ($marker, $ind, $gt, $qc) = split("\\s");
    if(!$data{$marker}){
        $data{$marker} = {};
    }
    ${%data}{$marker}{$ind} = $gt;
#   print "$marker $ind $gt\n";
}

my $firstLine = 1; # true

foreach my $marker (sort keys %data){
    if($firstLine){
        print(join(" ",sort keys %{$data{$marker}})."\n");
        $firstLine = 0; # false
    }
    print $marker;
    foreach my $ind (sort keys %{$data{$marker}}){
        print " ".${%data}{$marker}{$ind};
    }
    print "\n";
}
