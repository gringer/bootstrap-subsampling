#!/usr/bin/Rscript

argLoc <- 1;
infile.df <- FALSE;
infile.name <- FALSE;

while(!is.na(commandArgs(TRUE)[argLoc])){
  if(file.exists(commandArgs(TRUE)[argLoc])){ # file existence check
    if(infile.df == FALSE){
      infile.name <- commandArgs(TRUE)[argLoc];
      cat("Reading in file: ",infile.name,"...");
      infile.df <- read.table(gzfile(infile.name), nrows = 80500000);
                                        # 137s on assimilis for Chr22, T1D
      cat("done\n");
    } else{
      cat("Error: More than one input file specified\n");
      quit(save = "no", status=1);
    }
  }
  argLoc <- argLoc+1;
}

outfile.name <- sub("\\.txt.*$","_simplegt.txt",infile.name);

## p <- proc.time();
## infile.df <- read.table(gzfile("T1D/Affx_20070108fs1_gt_T1D_BRLMM96_22.txt.gz"), nrows = 20000000)
## print(proc.time() - p);

cat("Reordering data...");
infile.df <- infile.df[order(infile.df$V1, infile.df$V2),];
cat("done\n");

cat("Creating genotype matrix...");
outfile.gtmat <- as.character(infile.df$V3);
dim(outfile.gtmat) <- c(length(levels(infile.df$V2)), length(levels(infile.df$V1)));
dimnames(outfile.gtmat) <- list(levels(infile.df$V2), levels(infile.df$V1));
outfile.gtmat <- t(outfile.gtmat);
cat("done\n");

cat("Writing out file (",outfile.name,")...");
write.table(outfile.gtmat, file = outfile.name, quote = FALSE, sep = " ");
cat("done\n");

## infile.gtCounts <- (table(infile.df$V1, infile.df$V3));
## write.csv(infile.gtCounts,"Affx_20070108fs1_gt_T1D_BRLMM96_22_gtcounts.txt");
