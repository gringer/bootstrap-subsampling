#!/usr/bin/perl
use strict;
use warnings;

# assumes input is sorted by individual, then by marker (so once a
# different marker appears, the previous marker will never appear
# again in the file

my %data = ();
my $oldmarker = 0; # false
my $firstLine = 1; # true

while(<>){
    my ($marker, $ind, $gt, $qc) = split("\\s");
    if($marker ne $oldmarker){
        unless (!$oldmarker){
            if($firstLine){
                print(join(" ",sort keys %data)."\n");
                $firstLine = 0; # false
            }
            print $marker;
            foreach my $indiv (sort keys %data){
                print " ".$data{$indiv};
            }
            print "\n";
        }
        $oldmarker = $marker;
        %data = ();
    }
    $data{$ind} = $gt;
}

print $oldmarker;
foreach my $indiv (sort keys %data){
    print " ".$data{$indiv};
}
print "\n";
